import { saveStories } from './get-stories.mjs';

saveStories();
