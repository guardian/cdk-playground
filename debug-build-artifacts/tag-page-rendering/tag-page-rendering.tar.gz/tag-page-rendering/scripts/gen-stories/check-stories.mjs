import { checkStories } from './get-stories.mjs';

checkStories();
